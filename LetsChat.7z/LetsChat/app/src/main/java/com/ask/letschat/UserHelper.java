package com.ask.letschat;

public class UserHelper {
    String about,email,phone,work;

    public UserHelper(){}

    public UserHelper(String about, String email, String phone, String work) {
        this.about = about;
        this.email = email;
        this.phone = phone;
        this.work = work;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }
}
