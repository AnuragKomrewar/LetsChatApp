package com.ask.letschat;

import android.app.Dialog;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class ModalBottomSheet extends BottomSheetDialogFragment {

    private int layoutStyle;


    public ModalBottomSheet(int layoutStyle) {
        this.layoutStyle = layoutStyle;
    }

    @Override
    public void setupDialog(final Dialog dialog, int style) {
        super.setupDialog(dialog, style);

        View view = View.inflate(getContext(), this.layoutStyle, null);


        if (this.layoutStyle == R.layout.activity_chat) {

            view.findViewById(R.id.chatAddButton).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getContext(), "Preview layout 1", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            });
        } else {

        }

        dialog.setContentView(view);

    }


}
